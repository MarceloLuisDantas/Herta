-- Pacote principal que vai juntar tudo para fazer 
-- o interpretador funcionar.   

module Herta where

main :: IO ()
main = putStrLn "Hello, Haskell!"
